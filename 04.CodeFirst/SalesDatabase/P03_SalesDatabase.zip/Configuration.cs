﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase
{
    public class Configuration
    {
        public const string SqlConnectionString = @"Server=KING\SQLEXPRESS;Database=Hospital;Integrated Security = True;";
    }
}

